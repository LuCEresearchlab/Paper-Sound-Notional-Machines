{-# OPTIONS_GHC -Wall -Wno-orphans #-}

{-# LANGUAGE LambdaCase            #-}
{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE PatternSynonyms       #-}

module NotionalMachines.LangInMachine.UntypedLambdaExpressionTutor where

import Control.Monad.State.Lazy (State, StateT (..), lift)

import Data.Set (Set)

import qualified Hedgehog.Gen as Gen

import NotionalMachines.Lang.UntypedLambda.Generators (genCombinator, genExp)
import NotionalMachines.Lang.UntypedLambda.Main       (Exp (..), parse, unparse)

import NotionalMachines.Machine.ExpressionTutor.Main (ExpTutorDiagram (..), Node,
                                                      NodeContentElem (..), checkCycle, etToLang,
                                                      holeP, langToET, newDiaBranch, newDiaLeaf,
                                                      pattern DiaBranch, pattern DiaLeaf,
                                                      pattern MkNode)

import NotionalMachines.Lang.Error        (Error)
import NotionalMachines.Meta.Bisimulation (Bisimulation, mkInjBisim)
import NotionalMachines.Meta.Injective    (Injective, fromNM)
import NotionalMachines.Meta.LangToNM     (LangToNM (..))
import NotionalMachines.Meta.Steppable    (eval, step)


pattern NodeVar    :: String -> Int -> Node
pattern NodeLambda :: String -> Int -> Node
pattern NodeApp    :: Int -> Node

pattern NodeVar    name i <- MkNode i _       [NameUse name] where
        NodeVar    name i =  MkNode i Nothing [NameUse name]
pattern NodeLambda name i <- MkNode i _       [C "lambda", NameDef name, Hole {}] where
        NodeLambda name i =  MkNode i Nothing [C "lambda", NameDef name, holeP]
pattern NodeApp         i <- MkNode i _       [Hole {}, Hole {}] where
        NodeApp         i =  MkNode i Nothing [holeP,   holeP]

lambdaToET :: Exp -> ExpTutorDiagram
lambdaToET = langToET go
  where go :: Exp -> State Int ExpTutorDiagram
        go = \case
          Var name      -> newDiaLeaf   (NodeVar    name)
          Lambda name e -> newDiaBranch (NodeLambda name) go [e]
          App e1 e2     -> newDiaBranch  NodeApp          go [e1, e2]


etToLambda :: ExpTutorDiagram -> Maybe Exp
etToLambda = etToLang go
  where
    -- traverse diagram to build Exp keeping track of visited nodes to not get stuck
    go :: ExpTutorDiagram -> StateT (Set Int) Maybe Exp
    go d = checkCycle d $ case d of
      DiaLeaf   (NodeVar    name _)          -> return (Var name)
      DiaBranch (NodeLambda name _) [n]      -> Lambda name <$> go n
      DiaBranch (NodeApp    _)      [n1, n2] -> App <$> go n1 <*> go n2
      _                                      -> lift Nothing -- "incorrect diagram"


instance LangToNM Exp ExpTutorDiagram where
  toNM   = lambdaToET

instance Injective Exp ExpTutorDiagram Maybe where
  fromNM = etToLambda

bisim :: Bisimulation Exp Exp ExpTutorDiagram (Maybe ExpTutorDiagram)
bisim = mkInjBisim step
-- bisim = Bisim { fLang  = step
--               , fNM    = stepM
--               , alphaA = toNM
--               , alphaB = return . toNM }

------------------
-- Expression Tutor activities
------------------

---- Parse activity ----

genLambda :: IO String
genLambda = unparse <$> Gen.sample genExp

solveParseActivity :: String -> Either Error ExpTutorDiagram
solveParseActivity = fmap toNM . parse


---- Unparse activity ----

generateUnparseActivity :: IO ExpTutorDiagram
generateUnparseActivity = toNM <$> Gen.sample genExp

solveUnparseActivity :: ExpTutorDiagram -> Maybe String
solveUnparseActivity = fmap unparse . fromNM


---- Eval activity ----

generateEvalActivity :: IO String
generateEvalActivity = unparse <$> Gen.sample genCombinator

solveEvalActivity :: String -> Either Error ExpTutorDiagram
solveEvalActivity = fmap (toNM . eval) . parse


